<?php if($category->parent !== null): ?>
    <?php echo $__env->make('forum::partials.breadcrumb-categories', ['category' => $category->parent], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<li class="breadcrumb-item"><a href="<?php echo e(Forum::route('category.show', $category)); ?>"><?php echo e($category->title); ?></a></li>
<?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/partials/breadcrumb-categories.blade.php ENDPATH**/ ?>