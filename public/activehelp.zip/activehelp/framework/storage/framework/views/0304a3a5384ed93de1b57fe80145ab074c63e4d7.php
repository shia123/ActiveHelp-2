<div class="modal fade" tabindex="-1" role="dialog" data-modal="<?php echo e($key); ?>" data-close-modal>
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content shadow-sm">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo $title; ?></h5>
                <button type="button" class="btn-close" aria-label="Close" data-close-modal></button>
            </div>
            <form action="<?php echo e($route); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($method)): ?>
                    <?php echo method_field($method); ?>
                <?php endif; ?>

                <div class="modal-body">
                    <?php echo e($slot); ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-close-modal><?php echo e(trans('forum::general.cancel')); ?></button>
                    <?php echo e($actions); ?>

                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/modal-form.blade.php ENDPATH**/ ?>