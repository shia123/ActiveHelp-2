

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Remove user</div>

                <div class="card-body">
                    <?php $__currentLoopData = $group_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($group_member->id == auth()->user()->id): ?>
                            <p><?php echo e($group_member->username); ?> </p>
                        <?php else: ?>
                            <p><?php echo e($group_member->username); ?>  <small > <a class="text-danger" href="/remove_user/<?php echo e($group_id); ?>/<?php echo e($group_member->id); ?>" onclick="return confirm('Are  you sure?')"> Remove </a></small> </p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/group/members_list.blade.php ENDPATH**/ ?>