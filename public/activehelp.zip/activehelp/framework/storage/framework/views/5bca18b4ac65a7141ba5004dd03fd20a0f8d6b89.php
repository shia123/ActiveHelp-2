<div class="mb-3">
    <label for="color"><?php echo e(trans('forum::general.color')); ?></label>
    <div class="pickr"></div>
    <input type="hidden" value="<?php echo e(isset($category->color) ? $category->color : (old('color') ?? config('forum.web.default_category_color'))); ?>" name="color">
</div><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/category/partials/inputs/color.blade.php ENDPATH**/ ?>