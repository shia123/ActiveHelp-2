<?php $__env->startSection('content'); ?>
    <div id="thread" class="v-thread">
        <div class="d-flex flex-column flex-md-row justify-content-between">
            <h2 class="flex-grow-1"><?php echo e($thread->title); ?></h2>

            <div>
                <?php if(Gate::allows('deleteThreads', $thread->category) && Gate::allows('delete', $thread)): ?>
                    <?php if($thread->trashed()): ?>
                        <a href="#" class="btn btn-danger mr-3 mb-2" data-open-modal="perma-delete-thread">
                            <i data-feather="trash"></i> <?php echo e(trans('forum::general.perma_delete')); ?>

                        </a>
                    <?php else: ?>
                        <a href="#" class="btn btn-danger mr-3 mb-2" data-open-modal="delete-thread">
                            <i data-feather="trash"></i> <?php echo e(trans('forum::general.delete')); ?>

                        </a>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if($thread->trashed() && Gate::allows('restoreThreads', $thread->category) && Gate::allows('restore', $thread)): ?>
                    <a href="#" class="btn btn-secondary mb-2" data-open-modal="restore-thread">
                        <i data-feather="refresh-cw"></i> <?php echo e(trans('forum::general.restore')); ?>

                    </a>
                <?php endif; ?>

                <?php if(Gate::allows('lockThreads', $category)
                    || Gate::allows('pinThreads', $category)
                    || Gate::allows('rename', $thread)
                    || Gate::allows('moveThreadsFrom', $category)): ?>
                    <div class="btn-group mb-2" role="group">
                        <?php if(! $thread->trashed()): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lockThreads', $category)): ?>
                                <?php if($thread->locked): ?>
                                    <a href="#" class="btn btn-secondary" data-open-modal="unlock-thread">
                                        <i data-feather="unlock"></i> <?php echo e(trans('forum::threads.unlock')); ?>

                                    </a>
                                <?php else: ?>
                                    <a href="#" class="btn btn-secondary" data-open-modal="lock-thread">
                                        <i data-feather="lock"></i> <?php echo e(trans('forum::threads.lock')); ?>

                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pinThreads', $category)): ?>
                                <?php if($thread->pinned): ?>
                                    <a href="#" class="btn btn-secondary" data-open-modal="unpin-thread">
                                        <i data-feather="arrow-down"></i> <?php echo e(trans('forum::threads.unpin')); ?>

                                    </a>
                                <?php else: ?>
                                    <a href="#" class="btn btn-secondary" data-open-modal="pin-thread">
                                        <i data-feather="arrow-up"></i> <?php echo e(trans('forum::threads.pin')); ?>

                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rename', $thread)): ?>
                                <a href="#" class="btn btn-secondary" data-open-modal="rename-thread">
                                    <i data-feather="edit-2"></i> <?php echo e(trans('forum::general.rename')); ?>

                                </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moveThreadsFrom', $category)): ?>
                                <a href="#" class="btn btn-secondary" data-open-modal="move-thread">
                                    <i data-feather="corner-up-right"></i> <?php echo e(trans('forum::general.move')); ?>

                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>


        <div class="thread-badges">
            <?php if($thread->trashed()): ?>
                <span class="badge rounded-pill bg-danger"><?php echo e(trans('forum::general.deleted')); ?></span>
            <?php endif; ?>
            <?php if($thread->pinned): ?>
                <span class="badge rounded-pill bg-info"><?php echo e(trans('forum::threads.pinned')); ?></span>
            <?php endif; ?>
            <?php if($thread->locked): ?>
                <span class="badge rounded-pill bg-warning"><?php echo e(trans('forum::threads.locked')); ?></span>
            <?php endif; ?>
        </div>

        <hr>

        <?php if((count($posts) > 1 || $posts->currentPage() > 1) && (Gate::allows('deletePosts', $thread) || Gate::allows('restorePosts', $thread)) && count($selectablePosts) > 0): ?>
            <form :action="postActions[selectedPostAction]" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" :value="postActionMethods[selectedPostAction]" />
        <?php endif; ?>

        <div class="row mb-3">
            <div class="col col-xs-8">
                <?php echo e($posts->links('forum::pagination')); ?>

            </div>
            <div class="col-md-auto text-end">
                <?php if(! $thread->trashed()): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reply', $thread)): ?>
                        <div class="btn-group" role="group">
                            <a href="<?php echo e(Forum::route('post.create', $thread)); ?>" class="btn btn-primary">
                                <?php echo e(trans('forum::general.new_reply')); ?>

                            </a>
                            <a href="#quick-reply" class="btn btn-primary">
                                <?php echo e(trans('forum::general.quick_reply')); ?>

                            </a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <?php if((count($posts) > 1 || $posts->currentPage() > 1) && (Gate::allows('deletePosts', $thread) || Gate::allows('restorePosts', $thread)) && count($selectablePosts) > 0): ?>
            <div class="text-end pb-1">
                <div class="form-check">
                    <label for="selectAllPosts">
                        <?php echo e(trans('forum::posts.select_all')); ?>

                    </label>
                    <input type="checkbox" value="" id="selectAllPosts" class="align-middle" @click="toggleAll" :checked="selectedPosts.length == posts.data.length">
                </div>
            </div>
        <?php endif; ?>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('forum::post.partials.list', compact('post'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if((count($posts) > 1 || $posts->currentPage() > 1) && (Gate::allows('deletePosts', $thread) || Gate::allows('restorePosts', $thread)) && count($selectablePosts) > 0): ?>
                <div class="fixed-bottom-right pb-xs-0 pr-xs-0 pb-sm-3 pr-sm-3">
                    <transition name="fade">
                        <div class="card text-white bg-secondary shadow-sm" v-if="selectedPosts.length">
                            <div class="card-header text-center">
                                <?php echo e(trans('forum::general.with_selection')); ?>

                            </div>
                            <div class="card-body">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text" for="bulk-actions"><?php echo e(trans_choice('forum::general.actions', 1)); ?></label>
                                    </div>
                                    <select class="custom-select" id="bulk-actions" v-model="selectedPostAction">
                                        <option value="delete"><?php echo e(trans('forum::general.delete')); ?></option>
                                        <option value="restore"><?php echo e(trans('forum::general.restore')); ?></option>
                                    </select>
                                </div>

                                <?php if(config('forum.general.soft_deletes')): ?>
                                    <div class="form-check mb-3" v-if="selectedPostAction == 'delete'">
                                        <input class="form-check-input" type="checkbox" name="permadelete" value="1" id="permadelete">
                                        <label class="form-check-label" for="permadelete">
                                            <?php echo e(trans('forum::general.perma_delete')); ?>

                                        </label>
                                    </div>
                                <?php endif; ?>

                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary" @click="submitPosts"><?php echo e(trans('forum::general.proceed')); ?></button>
                                </div>
                            </div>
                        </div>
                    </transition>
                </div>
            </form>
        <?php endif; ?>

        <?php echo e($posts->links('forum::pagination')); ?>


        <?php if(! $thread->trashed()): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reply', $thread)): ?>
                <h3><?php echo e(trans('forum::general.quick_reply')); ?></h3>
                <div id="quick-reply">
                    <form method="POST" action="<?php echo e(Forum::route('post.store', $thread)); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-primary px-5"><?php echo e(trans('forum::general.reply')); ?></button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <?php if($thread->trashed() && Gate::allows('restoreThreads', $thread->category) && Gate::allows('restore', $thread)): ?>
        <?php $__env->startComponent('forum::modal-form'); ?>
            <?php $__env->slot('key', 'restore-thread'); ?>
            <?php $__env->slot('title', '<i data-feather="refresh-cw" class="text-muted"></i>' . trans('forum::general.restore')); ?>
            <?php $__env->slot('route', Forum::route('thread.restore', $thread)); ?>
            <?php $__env->slot('method', 'POST'); ?>

            <?php echo e(trans('forum::general.generic_confirm')); ?>


            <?php $__env->slot('actions'); ?>
                <button type="submit" class="btn btn-primary"><?php echo e(trans('forum::general.proceed')); ?></button>
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endif; ?>

    <?php if(Gate::allows('deleteThreads', $thread->category) && Gate::allows('delete', $thread)): ?>
        <?php $__env->startComponent('forum::modal-form'); ?>
            <?php $__env->slot('key', 'delete-thread'); ?>
            <?php $__env->slot('title', '<i data-feather="trash" class="text-muted"></i>' . trans('forum::threads.delete')); ?>
            <?php $__env->slot('route', Forum::route('thread.delete', $thread)); ?>
            <?php $__env->slot('method', 'DELETE'); ?>

            <?php if(config('forum.general.soft_deletes')): ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="permadelete" value="1" id="permadelete">
                    <label class="form-check-label" for="permadelete">
                        <?php echo e(trans('forum::general.perma_delete')); ?>

                    </label>
                </div>
            <?php else: ?>
                <?php echo e(trans('forum::general.generic_confirm')); ?>

            <?php endif; ?>

            <?php $__env->slot('actions'); ?>
                <button type="submit" class="btn btn-danger"><?php echo e(trans('forum::general.proceed')); ?></button>
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

        <?php if(config('forum.general.soft_deletes')): ?>
            <?php $__env->startComponent('forum::modal-form'); ?>
                <?php $__env->slot('key', 'perma-delete-thread'); ?>
                <?php $__env->slot('title', '<i data-feather="trash" class="text-muted"></i>' . trans_choice('forum::threads.perma_delete', 1)); ?>
                <?php $__env->slot('route', Forum::route('thread.delete', $thread)); ?>
                <?php $__env->slot('method', 'DELETE'); ?>

                <input type="hidden" name="permadelete" value="1" />

                <?php echo e(trans('forum::general.generic_confirm')); ?>


                <?php $__env->slot('actions'); ?>
                    <button type="submit" class="btn btn-danger"><?php echo e(trans('forum::general.proceed')); ?></button>
                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(! $thread->trashed()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lockThreads', $category)): ?>
            <?php if($thread->locked): ?>
                <?php $__env->startComponent('forum::modal-form'); ?>
                    <?php $__env->slot('key', 'unlock-thread'); ?>
                    <?php $__env->slot('title', '<i data-feather="unlock" class="text-muted"></i> ' . trans('forum::threads.unlock')); ?>
                    <?php $__env->slot('route', Forum::route('thread.unlock', $thread)); ?>
                    <?php $__env->slot('method', 'POST'); ?>

                    <?php echo e(trans('forum::general.generic_confirm')); ?>


                    <?php $__env->slot('actions'); ?>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans('forum::general.proceed')); ?></button>
                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php else: ?>
                <?php $__env->startComponent('forum::modal-form'); ?>
                    <?php $__env->slot('key', 'lock-thread'); ?>
                    <?php $__env->slot('title', '<i data-feather="lock" class="text-muted"></i> ' . trans('forum::threads.lock')); ?>
                    <?php $__env->slot('route', Forum::route('thread.lock', $thread)); ?>
                    <?php $__env->slot('method', 'POST'); ?>

                    <?php echo e(trans('forum::general.generic_confirm')); ?>


                    <?php $__env->slot('actions'); ?>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans('forum::general.proceed')); ?></button>
                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pinThreads', $category)): ?>
            <?php if($thread->pinned): ?>
                <?php $__env->startComponent('forum::modal-form'); ?>
                    <?php $__env->slot('key', 'unpin-thread'); ?>
                    <?php $__env->slot('title', '<i data-feather="arrow-down" class="text-muted"></i> ' . trans('forum::threads.unpin')); ?>
                    <?php $__env->slot('route', Forum::route('thread.unpin', $thread)); ?>
                    <?php $__env->slot('method', 'POST'); ?>

                    <?php echo e(trans('forum::general.generic_confirm')); ?>


                    <?php $__env->slot('actions'); ?>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans('forum::general.proceed')); ?></button>
                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php else: ?>
                <?php $__env->startComponent('forum::modal-form'); ?>
                    <?php $__env->slot('key', 'pin-thread'); ?>
                    <?php $__env->slot('title', '<i data-feather="arrow-up" class="text-muted"></i> ' . trans('forum::threads.pin')); ?>
                    <?php $__env->slot('route', Forum::route('thread.pin', $thread)); ?>
                    <?php $__env->slot('method', 'POST'); ?>

                    <?php echo e(trans('forum::general.generic_confirm')); ?>


                    <?php $__env->slot('actions'); ?>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans('forum::general.proceed')); ?></button>
                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rename', $thread)): ?>
            <?php $__env->startComponent('forum::modal-form'); ?>
                <?php $__env->slot('key', 'rename-thread'); ?>
                <?php $__env->slot('title', '<i data-feather="edit-2" class="text-muted"></i> ' . trans('forum::general.rename')); ?>
                <?php $__env->slot('route', Forum::route('thread.rename', $thread)); ?>
                <?php $__env->slot('method', 'POST'); ?>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="new-title"><?php echo e(trans('forum::general.title')); ?></label>
                    </div>
                    <input type="text" name="title" value="<?php echo e($thread->title); ?>" class="form-control">
                </div>

                <?php $__env->slot('actions'); ?>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('forum::general.proceed')); ?></button>
                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moveThreadsFrom', $category)): ?>
            <?php $__env->startComponent('forum::modal-form'); ?>
                <?php $__env->slot('key', 'move-thread'); ?>
                <?php $__env->slot('title', '<i data-feather="corner-up-right" class="text-muted"></i> ' . trans('forum::general.move')); ?>
                <?php $__env->slot('route', Forum::route('thread.move', $thread)); ?>
                <?php $__env->slot('method', 'POST'); ?>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="category-id"><?php echo e(trans_choice('forum::categories.category', 1)); ?></label>
                    </div>
                    <select name="category_id" id="category-id" class="form-select">
                        <?php echo $__env->make('forum::category.partials.options', ['hide' => $thread->category], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </select>
                </div>

                <?php $__env->slot('actions'); ?>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('forum::general.proceed')); ?></button>
                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
    <?php endif; ?>

    <style>
    .thread-badges .badge
    {
        font-size: 100%;
    }
    </style>

    <script>
    new Vue({
        el: '.v-thread',
        name: 'Thread',
        data: {
            posts: <?php echo json_encode($posts, 15, 512) ?>,
            selectablePosts: <?php echo json_encode($selectablePosts, 15, 512) ?>,
            postActions: {
                'delete': "<?php echo e(Forum::route('bulk.post.delete')); ?>",
                'restore': "<?php echo e(Forum::route('bulk.post.restore')); ?>"
            },
            postActionMethods: {
                'delete': 'DELETE',
                'restore': 'POST'
            },
            selectedPostAction: 'delete',
            selectedPosts: [],
            selectedThreadAction: null
        },
        created ()
        {
            this.posts.data = this.posts.data.filter(post => post.sequence != 1);
        },
        methods: {
            toggleAll ()
            {
                this.selectedPosts = (this.selectedPosts.length < this.selectablePosts.length) ? this.selectablePosts : [];
            },
            submitThread (event)
            {
                if (this.threadActionMethods[this.selectedThreadAction] === 'DELETE' && ! confirm("<?php echo e(trans('forum::general.generic_confirm')); ?>"))
                {
                    event.preventDefault();
                }
            },
            submitPosts (event)
            {
                if (this.postActionMethods[this.selectedPostAction] === 'DELETE' && ! confirm("<?php echo e(trans('forum::general.generic_confirm')); ?>"))
                {
                    event.preventDefault();
                }
            }
        }
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['thread' => null, 'breadcrumbs_append' => [$thread->title]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/thread/show.blade.php ENDPATH**/ ?>