<?php $__env->startComponent('forum::modal-form'); ?>
    <?php $__env->slot('key', 'edit-category'); ?>
    <?php $__env->slot('title', trans('forum::general.edit')); ?>
    <?php $__env->slot('route', Forum::route('category.update', $category)); ?>
    <?php $__env->slot('method', 'PATCH'); ?>

    <div class="mb-3">
        <label for="title"><?php echo e(trans('forum::general.title')); ?></label>
        <input type="text" name="title" value="<?php echo e(old('title') ?? $category->title); ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label for="description"><?php echo e(trans('forum::general.description')); ?></label>
        <input type="text" name="description" value="<?php echo e(old('description') ?? $category->description); ?>" class="form-control">
    </div>
    <div class="mb-3">
        <div class="form-check">
            <input type="hidden" name="accepts_threads" value="0" />
            <input class="form-check-input" type="checkbox" name="accepts_threads" id="accepts-threads" value="1" <?php echo e($category->accepts_threads ? 'checked' : ''); ?>>
            <label class="form-check-label" for="accepts-threads"><?php echo e(trans('forum::categories.enable_threads')); ?></label>
        </div>
    </div>
    <div class="mb-3">
        <div class="form-check">
            <input type="hidden" name="is_private" value="0" />
            <input class="form-check-input" type="checkbox" name="is_private" id="is-private" value="1" <?php echo e($category->is_private ? 'checked' : ''); ?> <?php echo e($privateAncestor != null ? 'disabled' : ''); ?>>
            <label class="form-check-label" for="is-private"><?php echo e(trans('forum::categories.make_private')); ?></label>
        </div>
    </div>
    <?php if($privateAncestor != null): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo trans('forum::categories.access_controlled_by_private_ancestor', ['category' => "<a href=\"{$privateAncestor->route}\">{$privateAncestor->title}</a>"]); ?>

        </div>
    <?php endif; ?>

    <?php echo $__env->make('forum::category.partials.inputs.color', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->slot('actions'); ?>
        <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans('forum::general.save')); ?></button>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/category/modals/edit.blade.php ENDPATH**/ ?>