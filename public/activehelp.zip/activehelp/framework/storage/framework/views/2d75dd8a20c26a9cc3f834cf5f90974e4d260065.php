<?php $__env->startComponent('forum::modal-form'); ?>
    <?php $__env->slot('key', 'mark-as-read'); ?>
    <?php $__env->slot('title', trans('forum::general.mark_read')); ?>
    <?php $__env->slot('route', Forum::route('unread.mark-as-read')); ?>
    <?php $__env->slot('method', 'PATCH'); ?>

    <p><?php echo e(trans('forum::general.generic_confirm')); ?></p>

    <?php $__env->slot('actions'); ?>
        <button type="submit" class="btn btn-primary pull-right">
            <?php echo e(trans('forum::general.mark_read')); ?>

        </button>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/thread/modals/mark-as-read.blade.php ENDPATH**/ ?>