<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- user id, will be used in vuejs for the real time chat -->
    <?php if(!Auth::guest()): ?>
        <meta name="user-id" content="<?php echo e(Auth::user()->id); ?>">
    <?php endif; ?>

    <title>Active Health</title>

    <!-- Scripts -->


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <style>
        .chat-box: {
            padding: 10px, 20px, 10px, 20px;
            border: 0.5px solid red; 
        }
    </style>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <div class="col-md-2">
                    <a class="navbar-brand" href="<?php echo e(Auth::guest() ? url('/') : url('/home')); ?>">
                        Active Health
                    </a>
                </div>   
                <?php if(!Auth::guest()): ?>
                    <div class="col-md-8">
                        <a class="navbar-brand" href="<?php echo e(url(config('forum.web.router.prefix'))); ?>">
                                    Go to Forum
                            </a>    
                    </div>    
                    <div class="col-md-2">

                   

                    <?php
                        $userid= Auth::user()->uuid;
                        if ($userid == '1'){
                            echo '<style> .create-gc{
                                display:block
                            }</style>';
                        }else{
                            echo '<style> .create-gc{
                                display:none
                            }</style>';
                        }
                    ?>
                    
                        

                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->make('partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/layouts/app.blade.php ENDPATH**/ ?>