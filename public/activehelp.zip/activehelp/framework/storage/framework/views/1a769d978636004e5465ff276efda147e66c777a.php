<?php $__env->startSection('content'); ?>
    <div id="new-posts">
        <h2><?php echo e(trans('forum::threads.unread_updated')); ?></h2>

        <?php if(! $threads->isEmpty()): ?>
            <div class="threads list-group my-3 shadow-sm">
                <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('forum::thread.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="card my-3">
                <div class="card-body text-center text-muted">
                    <?php echo e(trans('forum::threads.none_found')); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if(! $threads->isEmpty()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('markThreadsAsRead')): ?>
            <div class="text-center">
                <button class="btn btn-primary px-5" data-open-modal="mark-as-read">
                    <i data-feather="book"></i> <?php echo e(trans('forum::general.mark_read')); ?>

                </button>
            </div>

            <?php echo $__env->make('forum::thread.modals.mark-as-read', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['thread' => null, 'breadcrumbs_append' => [trans('forum::threads.unread_updated')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/thread/unread.blade.php ENDPATH**/ ?>