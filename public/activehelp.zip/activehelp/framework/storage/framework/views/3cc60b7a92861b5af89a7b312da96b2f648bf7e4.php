<?php $__env->startSection('content'); ?>
    <div id="post">
        <div class="d-flex flex-row justify-content-between mb-3">
            <h2 class="flex-grow-1"><?php echo e(trans('forum::posts.view')); ?> (<?php echo e($thread->title); ?>)</h2>
            <a href="<?php echo e(Forum::route('thread.show', $thread)); ?>" class="btn btn-secondary btn-lg"><?php echo e(trans('forum::threads.view')); ?></a>
        </div>

        <hr>

        <?php echo $__env->make('forum::post.partials.list', ['post' => $post, 'single' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumbs_append' => [trans('forum::posts.view')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/post/show.blade.php ENDPATH**/ ?>