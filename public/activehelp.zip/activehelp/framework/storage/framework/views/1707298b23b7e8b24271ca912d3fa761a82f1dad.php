<?php if(session('success')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session('success')); ?></strong>
    </div>
<?php elseif(session('error')): ?>
    <div class="alert alert-danger">
        <strong><?php echo e(session('error')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/partials/error_message.blade.php ENDPATH**/ ?>