

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3> Chat : <?php echo e($group->name); ?> </h3>
                    <?php 
                        $userid= Auth::user()->uuid;
                        if($userid =='2022' || $userid =='9832'){
                    ?>
                    <span class="text-danger">Code to join: <?php echo e($group->code); ?></span>
                    <?php }?>
                    <?php if($group->admin_id == auth()->user()->id): ?>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <p>
                                    <a class="btn btn-info" href="/group/edit/<?php echo e($group->id); ?>" style="color:white;">Edit</a>
                                </p>
                            </div>
                            
                            <div class="col-md-4">
                                <form action="/group/delete/<?php echo e($group->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('Delete'); ?>

                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete chat room</button>
                                </form>
                            </div>

                            <div class="col-md-4">
                                <p>
                                    <a class="btn btn-warning" href="/group/members_list/<?php echo e($group->id); ?>" style="color:white;">Remove users</a>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                </div>

                <div class="card-body container">
                    <div class="message-container mb-5" id="message-container" style="overflow-y: scroll; height:400px;" v-chat-scroll>
                        <message v-for="(message, id) in chat "
                        v-bind:key="id"
                        v-bind:message = "message.message"
                        v-bind:username = "message.user.username"
                        v-bind:user_id = "message.user.id"
                        v-bind:created_at = "message.created_at"
                        >
                        </message>
                    </div>

                    <form action="/send_message/<?php echo e($group->id); ?>" method="post" v-on:submit='send_message'>
                        <?php echo csrf_field(); ?>

                        <textarea name="message" id="message" v-model="message" class="col-md-12 form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="20" rows="5"></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button class="btn btn-primary" type="submit">Send message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!--script>
    window.onload=function () {
     var objDiv = document.getElementById("message-container");
     objDiv.scrollTop = objDiv.scrollHeight;
}
</script-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/group/show.blade.php ENDPATH**/ ?>