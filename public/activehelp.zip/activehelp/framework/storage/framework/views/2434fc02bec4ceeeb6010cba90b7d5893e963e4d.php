<div <?php if(! $post->trashed()): ?>id="post-<?php echo e($post->sequence); ?>"<?php endif; ?>
    class="post card mb-2 <?php echo e($post->trashed() || $thread->trashed() ? 'deleted' : ''); ?>"
    :class="{ 'border-primary': selectedPosts.includes(<?php echo e($post->id); ?>) }">
    <div class="card-header">
        <?php if(! isset($single) || ! $single): ?>
            <span class="float-end">
                <a href="<?php echo e(Forum::route('thread.show', $post)); ?>">#<?php echo e($post->sequence); ?></a>
                <?php if($post->sequence != 1): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deletePosts', $post->thread)): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                            <input type="checkbox" name="posts[]" :value="<?php echo e($post->id); ?>" v-model="selectedPosts">
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </span>
        <?php endif; ?>

        <?php echo e($post->authorName); ?>


        <span class="text-muted">
            <?php echo $__env->make('forum::partials.timestamp', ['carbon' => $post->created_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($post->hasBeenUpdated()): ?>
                (<?php echo e(trans('forum::general.last_updated')); ?> <?php echo $__env->make('forum::partials.timestamp', ['carbon' => $post->updated_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>)
            <?php endif; ?>
        </span>
    </div>
    <div class="card-body">
        <?php if($post->parent !== null): ?>
            <?php echo $__env->make('forum::post.partials.quote', ['post' => $post->parent], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if($post->trashed()): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewTrashedPosts')): ?>
                <?php echo Forum::render($post->content); ?>

                <br>
            <?php endif; ?>
            <span class="badge rounded-pill bg-danger"><?php echo e(trans('forum::general.deleted')); ?></span>
        <?php else: ?>
            <?php echo Forum::render($post->content); ?>

        <?php endif; ?>

        <?php if(! isset($single) || ! $single): ?>
            <div class="text-end">
                <?php if(! $post->trashed()): ?>
                    <a href="<?php echo e(Forum::route('post.show', $post)); ?>" class="card-link text-muted"><?php echo e(trans('forum::general.permalink')); ?></a>
                    <?php if($post->sequence != 1): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deletePosts', $post->thread)): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                                <a href="<?php echo e(Forum::route('post.confirm-delete', $post)); ?>" class="card-link text-danger"><?php echo e(trans('forum::general.delete')); ?></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $post)): ?>
                        <a href="<?php echo e(Forum::route('post.edit', $post)); ?>" class="card-link"><?php echo e(trans('forum::general.edit')); ?></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reply', $post->thread)): ?>
                        <a href="<?php echo e(Forum::route('post.create', $post)); ?>" class="card-link"><?php echo e(trans('forum::general.reply')); ?></a>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restorePosts', $post->thread)): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restore', $post)): ?>
                            <a href="<?php echo e(Forum::route('post.confirm-restore', $post)); ?>" class="card-link"><?php echo e(trans('forum::general.restore')); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/post/partials/list.blade.php ENDPATH**/ ?>