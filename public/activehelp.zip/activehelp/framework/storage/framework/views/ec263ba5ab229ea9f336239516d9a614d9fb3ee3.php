<?php $__env->startSection('content'); ?>
    <div id="create-post">
        <h2><?php echo e(trans('forum::general.new_reply')); ?> (<?php echo e($thread->title); ?>)</h2>

        <?php if(!$post === null && !$post->trashed()): ?>
            <p><?php echo e(trans('forum::general.replying_to', ['item' => $post->authorName])); ?>:</p>

            <?php echo $__env->make('forum::post.partials.quote', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(Forum::route('post.store', $thread)); ?>">
            <?php echo csrf_field(); ?>

            <?php if($post !== null): ?>
                <input type="hidden" name="post" value="<?php echo e($post->id); ?>">
            <?php endif; ?>

            <div class="mb-3">
                <textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea>
            </div>

            <div class="text-end">
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-link"><?php echo e(trans('forum::general.cancel')); ?></a>
                <button type="submit" class="btn btn-primary px-5"><?php echo e(trans('forum::general.reply')); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumbs_append' => [trans('forum::general.new_reply')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/post/create.blade.php ENDPATH**/ ?>