

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-6">
                        <?php 
                            $userid= Auth::user()->uuid;
                            if($userid =='2022' || $userid =='9832'){
                        ?>

                            <a class="btn btn-primary create-gc" href="/group/create">Create a chat room</a>

                        <?php }?>    

                        </div>
                        <div class="col-md-6" style="text-align: right;">
                            <a class="btn btn-light" href="/group/join">Join a chat room</a>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-md-12 mt-5">
                            <div class="card">
                                <div class="card-header">Private Chat & Community Chat</div>

                                <div class="card-body">
                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h4> <a href="/group/<?php echo e($group->id); ?>" style="color: black;"> <?php echo e($group->name); ?> </a> </h4>
                                        </div>
                                        <?php 
                                            $userid= Auth::user()->uuid;
                                            if($userid =='2022' || $userid =='9832'){
                                        ?>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h5>Code:</h5>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="text-danger"><?php echo e($group->code); ?></p>
                                                </div>
                                            </div>
                                        </div>

                                        <?php }?>
                                    </div> <br>
                                    <p>
                                        <?php if($group->messages()->latest()->first()): ?>
                                            <span class="text-danger"><?php echo e($group->messages()->latest()->first()->user->username); ?></span> <small><?php echo e($group->messages()->latest()->first()->message); ?></small>
                                        <?php endif; ?>
                                    </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/home.blade.php ENDPATH**/ ?>