

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-row justify-content-between mb-2">
        <h2 class="flex-grow-1"><?php echo e(trans('forum::general.manage')); ?></h2>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createCategories')): ?>
            <button type="button" class="btn btn-primary" data-open-modal="create-category">
                <?php echo e(trans('forum::categories.create')); ?>

            </button>

            <?php echo $__env->make('forum::category.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>

    <div class="v-manage-categories">
        <draggable-category-list :categories="categories"></draggable-category-list>

        <transition name="fade">
            <div v-show="changesApplied" class="alert alert-success mt-3" role="alert">
                <?php echo e(trans('forum::general.changes_applied')); ?>

            </div>
        </transition>

        <div class="text-end py-3">
            <button type="button" class="btn btn-primary px-5" :disabled="isSavingDisabled" @click="onSave">
                <?php echo e(trans('forum::general.save')); ?>

            </button>
        </div>
    </div>

    <script type="text/x-template" id="draggable-category-list-template">
        <draggable tag="ul" class="list-group" :list="categories" group="categories" :invertSwap="true" :emptyInsertThreshold="14">
            <li class="list-group-item" v-for="category in categories" :data-id="category.id" :key="category.id">
                <a class="float-end btn btn-sm btn-danger ml-2" :href="`${category.route}#modal=delete-category`"><?php echo e(trans('forum::general.delete')); ?></a>
                <a class="float-end btn btn-sm btn-link ml-2" :href="`${category.route}#modal=edit-category`"><?php echo e(trans('forum::general.edit')); ?></a>
                <strong :style="{ color: category.color }">{{ category.title }}</strong>
                <div class="text-muted">{{ category.description }}</div>

                <draggable-category-list :categories="category.children"></draggable-category-list>
            </li>
        </draggable>
    </script>

    <script>
    var draggableCategoryList = {
        name: 'draggable-category-list',
        template: '#draggable-category-list-template',
        props: ['categories']
    };

    new Vue({
        el: '.v-manage-categories',
        name: 'ManageCategories',
        components: {
            draggableCategoryList
        },
        data: {
            categories: <?php echo json_encode($categories, 15, 512) ?>,
            isSavingDisabled: true,
            changesApplied: false
        },
        watch: {
            categories: {
                handler: function (categories) {
                    this.isSavingDisabled = false;
                },
                deep: true
            }
        },
        methods: {
            onSave ()
            {
                this.isSavingDisabled = true;
                this.changesApplied = false;

                var payload = { categories: this.categories };
                axios.post('<?php echo e(route('forum.bulk.category.manage')); ?>', payload)
                    .then(response => {
                        this.changesApplied = true;
                        setTimeout(() => this.changesApplied = false, 3000);
                    })
                    .catch(error => {
                        this.isSavingDisabled = false;
                        console.log(error);
                    });
            }
        }
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('forum::master', ['category' => null, 'thread' => null, 'breadcrumbs_append' => [trans('forum::general.manage')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/category/manage.blade.php ENDPATH**/ ?>