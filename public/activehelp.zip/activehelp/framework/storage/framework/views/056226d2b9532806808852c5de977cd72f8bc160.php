<?php $__env->startComponent('forum::modal-form'); ?>
    <?php $__env->slot('key', 'create-category'); ?>
    <?php $__env->slot('title', trans('forum::categories.create')); ?>
    <?php $__env->slot('route', Forum::route('category.store')); ?>

    <div class="mb-3">
        <label for="title"><?php echo e(trans('forum::general.title')); ?></label>
        <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label for="description"><?php echo e(trans('forum::general.description')); ?></label>
        <input type="text" name="description" value="<?php echo e(old('description')); ?>" class="form-control">
    </div>
    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="accepts_threads" id="accepts-threads" value="1" <?php echo e(old('accepts_threads') ? 'checked' : ''); ?>>
            <label class="form-check-label" for="accepts-threads"><?php echo e(trans('forum::categories.enable_threads')); ?></label>
        </div>
    </div>
    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="is_private" id="is-private" value="1" <?php echo e(old('is_private') ? 'checked' : ''); ?>>
            <label class="form-check-label" for="is-private"><?php echo e(trans('forum::categories.make_private')); ?></label>
        </div>
    </div>
    <?php echo $__env->make('forum::category.partials.inputs.color', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->slot('actions'); ?>
        <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans('forum::general.create')); ?></button>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\activehelp-files-2022\testing-chat-site\group-chat\resources\views/vendor/forum/category/modals/create.blade.php ENDPATH**/ ?>