<?php

namespace App\Botman;

use BotMan\BotMan\Messages\Incoming\Answer;
use BotMan\BotMan\Messages\Outgoing\Question;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Conversations\Conversation;

class BookingConversation extends Conversation
{
    public function confirmBooking()
    {
        $user = $this->bot->userStorage()->find();

        $message = '-------------------------------------- <br>';
        $message .= 'Name : ' . $user->get('name') . '<br>';
        $message .= 'Email : ' . $user->get('email') . '<br>';
        $message .= 'Mobile : ' . $user->get('mobile') . '<br>';
        $message .= 'I Feel : ' . $user->get('feel') . '<br>';
        $message .= '<a href="http://127.0.0.1:8000/#doctor-chat"><button class="btn" >Book Now</button></a><br>';
        $message .= '---------------------------------------';

        $this->say('Here is your booking details. <br><br>' . $message);
    }

    public function run()
    {
        $this->confirmBooking();
    }
}