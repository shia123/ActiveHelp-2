<?php

namespace App\Botman;


use Validator;
use BotMan\BotMan\Messages\Outgoing\Question;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Conversations\Conversation;
use BotMan\BotMan\Messages\Incoming\Answer;

class OnboardingConversation extends Conversation
{
    protected $name;

    protected $email;

    // protected $query;

    public function askName()
    {
        $this->ask('What do you want me to call you?', function(Answer $answer) {
            $this->bot->userStorage()->save([
                'name' => $answer->getText(),
            ]);

            $this->say('Hi, '. $answer->getText().'! It’s nice to meet you!');
            $this->askEmail();
        });
    }

    public function askEmail()
    {
        $this->ask('What is your email?', function(Answer $answer) {
            // Save result
            // $this->email = $answer->getText();

            $validator = Validator::make(['email' => $answer->getText()], [
                'email' => 'email',
            ]);

            if ($validator->fails()) {
                return $this->repeat('That doesn\'t look like a valid email. Please enter a valid email.');
            }

            $this->bot->userStorage()->save([
                'email' => $answer->getText(),
            ]);

            // $this->say('Great - that is all we need, '.$this->name);
            $this->askMobile();
        });
    }

    public function askMobile()
    {
        $this->ask('Great. What is your mobile?', function(Answer $answer) {
            $this->bot->userStorage()->save([
                'mobile' => $answer->getText(),
            ]);
    
            $this->say('Great!');
    
            $this->bot->startConversation(new SelectServiceConversation()); // Trigger the next conversation
        });
    }

    public function run()
    {
        // This will be called immediately
        $this->askName();
    }
}