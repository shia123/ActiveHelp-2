<?php

namespace App\Botman;

use BotMan\BotMan\Messages\Incoming\Answer;
use BotMan\BotMan\Messages\Outgoing\Question;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Conversations\Conversation;

class SelectServiceConversation extends Conversation
{
    public function askService()
    {
        $question = Question::create('Did you feel depressed or sad this week?')
            ->callbackId('select_feel')
            ->addButtons([
                Button::create('Not at all')->value('Not at all'),
                Button::create('Several Days')->value('Several Days'),
                Button::create('Most Days')->value('Most Days'),
                Button::create('Nearly Every Day')->value('Nearly Every Day'),
                
            ]);

        $this->ask($question, function(Answer $answer) {
            if ($answer->isInteractiveMessageReply()) {
                $this->bot->userStorage()->save([
                    'feel' => $answer->getValue(),
                ]);

                $this->say($answer->getText());
            }

            $this->bot->startConversation(new BookingConversation()); // Trigger the next conversation

        });
    }

    public function run()
    {
        $this->askService();
    }
}